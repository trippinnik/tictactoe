﻿using System;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Web;
using tictactoe.Models;

namespace tictactoe.Controllers
{
    /// <summary>
    /// Defines methods that implement the tictactoe resource
    /// </summary>
    [Route("api/v1/[controller]/executemove")] //indicating v1
    [Produces("application/json")] // See: https://en.wikipedia.org/wiki/Media_type  
    public class TicTacToe : Controller
    {
        /// <summary>
        /// initialize a new instance of the <see cref="TicTacToe"/> class
        /// </summary>
        public TicTacToe()
        {

        }

        /// <summary>
        /// the post method for the execute which returns the gameboard and 
        /// </summary>
        ///<example>
        ///{
	    ///"gameBoard":[
		///"X",
		///"X",
		///"O",
		///"?",
		///"?",
		///"?",
		///"?",
		///"?",
		///"?"
		///]
    /// }
    /// </example>
    /// Post must be array of string, type gameBoard. Array must be length 9 and strings must be X, O or ?
    // POST api/values
    [ProducesResponseType(typeof(ExecuteMoveResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(string), (int) HttpStatusCode.BadRequest)]
        [HttpPost()]
        public ExecuteMoveResponse Post([FromBody] GameBoard receivedGameboard)
        {
            GameBoardValidation gameboardValidation = new GameBoardValidation();
            gameboardValidation.gameBoard = receivedGameboard.gameBoard;
            if (gameboardValidation.IsValid())
            {
                ExecuteMoveResponse moveResponse = new ExecuteMoveResponse();
                moveResponse = moveResponse.ExecuteMove(receivedGameboard);
                return moveResponse;
            }
            else
            {
                
                throw new HttpResponseException(Request.CreateErrorResponse(HttpStatusCode.NotFound, String.Format("Check that your Gameboard is 9 spots and conists of 'X', 'O' or '?'."))); 
            }
            
            


        }

        
    }
}
    

